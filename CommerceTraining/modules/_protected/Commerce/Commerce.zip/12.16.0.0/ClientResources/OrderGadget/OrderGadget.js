﻿define([
    "dojo/query",
    "dojo/dom-style",
    "epi",
    "epi/shell/widget/Iframe"
],

function (
    query,
    domStyle,
    epi,
    Iframe
) {

    (function ($) {
        epi.orderGadget = function () {
            // object returned by function. Exposes public methods and variables.
            var pub = {};

            pub.init = function (e, gadgetInstance) {
                var viewLoaded = function (e, gadgetInstance) {
                    if (gadgetInstance.routeParams && gadgetInstance.routeParams.action != "Configure") {
                        var domNode = query(".epiOrderGadget", gadgetInstance.element)[0];
                        if (domNode) {
                            var urlAction = gadgetInstance.getActionPath({ action: "ShowReport" });
                            var widget = new Iframe({ src: urlAction }, domNode);
                            widget.startup();

                            // hide iFrame's Container scrollbar
                            domStyle.set(gadgetInstance.gadgetContent.domNode, "padding", 0);
                            domStyle.set(gadgetInstance.gadgetContent.domNode, "height", "100%");
                            domStyle.set(gadgetInstance.element, "overflow", "hidden");
                            domStyle.set(widget.domNode, "height", "100%");
                        }
                    }
                };
                // Listen to the loaded event raised each time a gadget view has been loaded
                $(this).bind("epigadgetloaded", viewLoaded);
            };

            return pub;
        } ();
    } (epiJQuery));
});