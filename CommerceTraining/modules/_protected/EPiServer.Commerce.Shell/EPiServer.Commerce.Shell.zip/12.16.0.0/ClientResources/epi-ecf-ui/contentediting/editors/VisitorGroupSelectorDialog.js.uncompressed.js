require({cache:{
'url:epi-ecf-ui/widget/templates/_SelectorDialog.html':"﻿<div>\r\n    <div class=\"epi-searchbox-container\">\r\n        <div data-dojo-type=\"epi/shell/widget/SearchBox\" data-dojo-attach-point=\"searchBox\"\r\n             class=\"epi-search--full-width\" data-dojo-attach-event=\"onSearchBoxChange:_onSearchBoxChange\"\r\n             data-dojo-props=\"placeHolder: '${resources.searchplaceholder}', triggerChangeOnEnter: false\"></div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"noDataMessage\" style=\"display:none\" class=\"dgrid-no-data\">${noDataMessageResources.nosearchresults}</div>\r\n    <div data-dojo-attach-point=\"listContainer\" />\r\n</div>"}});
define("epi-ecf-ui/contentediting/editors/VisitorGroupSelectorDialog", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-style",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi-ecf-ui
    "./VisitorGroupList",
// resources
    "dojo/text!../../widget/templates/_SelectorDialog.html",
    "epi/i18n!epi/nls/commerce.widget.visitorgroupselector",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.hierachicallist"
], function (
// dojo
    declare,
    domStyle,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi-ecf-ui
    VisitorGroupList,
// resources
    templates,
    resources,
    noDataMessageResources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //      Represents the widget which contains the list of visitor groups.
        // tags:
        //    internal product

        // templateString: [protected] String
        //      Widget's template string.
        templateString: templates,

        resources: resources,

        noDataMessageResources: noDataMessageResources,

        postCreate: function () {
            this.inherited(arguments);
            this._visitorGroupList = this._visitorGroupList || new VisitorGroupList({}, this.listContainer);
            this.own(this._visitorGroupList);
        },

        _onSearchBoxChange: function (queryText) {
            // summary:
            //      handle searchBoxChange event.
            // queryText: [string]
            //      the query text to filter visitor groups.
            // tags:
            //      Private
            var allVisitorGroups = this.get("allVisitorGroups");
            if (!queryText){
                this._showVisitorGroups(allVisitorGroups, false);
                return;
            }
            var lowerCaseQueryText = queryText.toLowerCase();
            var filteredVisitorGroups = allVisitorGroups.filter(function(visitorGroup){
                return visitorGroup.name.toLowerCase().indexOf(lowerCaseQueryText) > -1;
            });
            this._showVisitorGroups(filteredVisitorGroups, true);
        },

        _showVisitorGroups: function (visitorGroups, isSearching) {
            // summary:
            //      show or hide the search results
            // tags:
            //      Private
            var hasResults = !isSearching || visitorGroups && visitorGroups.length > 0;
            domStyle.set(this.noDataMessage, "display", hasResults ? "none" : "");
            domStyle.set(this._visitorGroupList.domNode, "display", hasResults ? "" : "none");
            if (hasResults){
                this._visitorGroupList.set("visitorGroups", visitorGroups);
            }
        },

        _getSelectedVisitorGroupsAttr: function () {
            return this._visitorGroupList.getSelectedVisitorGroupIds();
        },

        _setSelectedVisitorGroupsAttr: function (value) {
            this._visitorGroupList.setSelection(value);
        },

        _setAllVisitorGroupsAttr: function(value) {
            this._set("allVisitorGroups", value);
            // clearing the searchbox will trigger _onSearchBoxChange and show all visitor groups
            this.searchBox.clearValue();
        }
    });
});