﻿define("epi-ecf-ui/contentediting/viewmodel/CategoryCollectionReadOnlyEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/when",

    // ecf
    "../ModelSupport",
    "./ReadOnlyCollectionEditorModel"
],
    function (
        // dojo
        declare,
        when,

        // ecf
        ModelSupport,
        ReadOnlyCollectionEditorModel
    ) {
        return declare([ReadOnlyCollectionEditorModel], {
            // module: 
            //      epi-ecf-ui/contentediting/viewmodel/RelationCollectionEditorModel
            // summary:
            //      Represents the model for RelationCollectionEditor

            _storeKey: "epi.commerce.relation",

            primaryCategory: null,

            // summary:
            //      It is possible to sort listed categories.
            // tags: 
            //      protected
            _enableSorting: true,

            _preprocessResult: function (result) {

                var copiedResult = result.slice();
                var primaryCategoryIndex;
                this.set("primaryCategory", null);

                return when(this.getCurrentContent()).then(function (content) {

                    copiedResult.some(function (relationNode, index) {
                        if (relationNode.target === content.parentLink) {
                            this.set("primaryCategory", relationNode);
                            primaryCategoryIndex = index;

                            return true;
                        }
                    }, this);

                    if (typeof (primaryCategoryIndex) === "number") {
                        copiedResult.splice(primaryCategoryIndex, 1);
                    }

                    return copiedResult;

                }.bind(this));
            },

            createQuery: function (referenceId) {
                return { referenceId: referenceId, relationTypes: [ModelSupport.relationType.node] };
            }
        });
    });