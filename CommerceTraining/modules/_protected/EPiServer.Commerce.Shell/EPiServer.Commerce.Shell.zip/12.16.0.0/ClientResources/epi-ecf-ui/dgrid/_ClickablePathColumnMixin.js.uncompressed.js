﻿define("epi-ecf-ui/dgrid/_ClickablePathColumnMixin", [
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/topic",
    "epi/shell/DestroyableByKey",
    "../contentediting/ModelSupport"
], function (
    declare,
    aspect,
    topic,
    DestroyableByKey,
    ModelSupport
) {
        return declare([DestroyableByKey], {

            postCreate: function () {
                this.inherited(arguments);
                this._setupClickablePathColumn();
            },

            _setupClickablePathColumn: function () {
                this.ownByKey("pathColumnClick", this.on(".dgrid-cell.dgrid-column-path:click", this._publishContextRequestForPathClick.bind(this)));
                for (var columnName in this.columns) {
                    if (columnName === "path") {
                        this.columns[columnName].className = "epi-ecf-uiPathLink";
                    }
                }
            },

            _publishContextRequestForPathClick: function (event) {
                var row = this.row(event);

                if (row) {
                    var contentLink = row.data.requestMode === ModelSupport.relationRequestMode.byTarget ? row.data.source : row.data.target;
                    topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + contentLink }, { sender: this });
                }
            }
        });
    });