require({cache:{
'url:epi-ecf-ui/widget/templates/_FacetGroupItem.html':"﻿<div class=\"epi-mo epi-facet-group-item\">\r\n    <span class=\"epi-mo--img\">\r\n        <span class=\"dijitIcon ${iconClasses}\"></span>\r\n    </span>\r\n    <div class=\"epi-mo--body\">\r\n        <div class=\"dijitInline epi-card__title--ellipsis-wrapper\">\r\n            <span class=\"dijitInline epi-card__title dojoxEllipsis\" title=\"${name}\">${name}</span>\r\n        </div>\r\n        <span class=\"epi-facet-group-item__matching-number epi-pill epi-floatRight\">${count}</span>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/FacetGroup", [
// dojo
    "dojo/_base/declare",

    "dojo/aspect",

    "dojo/dom-class",
    "dojo/dom-geometry",

    "dojo/Evented",
    "dojo/html",
    "dojo/query",
    "dojo/string",
    "dojo/when",
// dojox
    "dojox/html/entities",
// dijit
    "dijit/form/ToggleButton",
    "dijit/layout/_LayoutWidget",
// dgrid
    "dgrid/Keyboard",
    "dgrid/OnDemandList",
    "dgrid/Selection",
// epi
    "epi",

    "epi/shell/dgrid/Focusable",
    "epi/shell/dgrid/Formatter",
    "epi/shell/dgrid/Responsive",

    "epi/shell/widget/_ModelBindingMixin",
// epi-ecf-ui
    "./CollapsibleContainer",
// resources
    "dojo/text!./templates/_FacetGroupItem.html",
    "epi/i18n!epi/cms/nls/commerce.widget.facets"
], function (
// dojo
    declare,

    aspect,

    domClass,
    domGeometry,

    Evented,
    html,
    query,
    string,
    when,
// dojox
    entities,
// dijit
    ToggleButton,
    _LayoutWidget,
// dgrid
    Keyboard,
    OnDemandList,
    Selection,
// epi
    epi,

    Focusable,
    Formatter,
    Responsive,

    _ModelBindingMixin,
// epi-ecf-ui
    CollapsibleContainer,
// resources
    facetItemTemplate,
    resources
) {

    return declare([_LayoutWidget, _ModelBindingMixin, CollapsibleContainer, Evented], {
        // summary:
        //      Represents the widget to filter group in the facet.
        // tags:
        //      public

        modelBindingMap: {
            name: ["title"],// Set in CollapsibleContainer widget.
            collapsible: ["collapsible"],// Set in CollapsibleContainer widget.
            showMatchingItems: ["showMatchingItems"],
            selectionType: ["selectionType"],
            selection: ["selection"],
            listStore: ["listStore"],
            recalculatedItems: ["recalculatedItems"]
        },

        _setShowMatchingItemsAttr: function (showMatchingItems) {
            domClass.toggle(this.domNode, "epi-facet-group--count-item-invisible", !showMatchingItems);
        },

        _setSelectionTypeAttr: function (selectionType) {
            this._set("selectionType", selectionType);

            this._list && this._list.set("selectionMode", selectionType === 0 ? "single" : "multiple");
        },

        _setSelectionAttr: function (items) {
            // summary:
            //      Sets the selection in the list and emit selection-changed with the given facet items
            // tags:
            //      protected

            this._list.clearSelection();

            if (items instanceof Array) {
                var singleSelectionMode = this.get("selectionType") === 0;
                if (items.length === 0 && singleSelectionMode) {
                    // Set selected for default item of single selection group.
                    this._list.select("");
                    return;
                }

                var listStore = this.model.get("listStore"),
                    validItems = items.filter(function (item) {
                        return when(listStore.get(item), function (validItem) {
                            return !!validItem;
                        });
                    });

                // If has an invalid item then emit selection-changed with only valid items to remove invalid item.
                if (validItems.length !== items.length) {
                    this.emit("selection-changed", { "id": this.model.get("id"), items: validItems });
                    return;
                }

                validItems.forEach(this._list.select, this._list);
            }

            this._toggleClearButton();
        },

        _setListStoreAttr: function (listStore) {
            this._list && this._list.set("store", listStore);
            this.layout();
        },

        _setRecalculatedItemsAttr: function (items) {
            if (epi.isEmpty(items)) {
                return;
            }

            var listId = this._list.get("id");
            items.forEach(function (item) {
                var matchingNumberNode = query("#" + listId + "-row-" + item.id + " .epi-facet-group-item__matching-number")[0];
                matchingNumberNode && html.set(matchingNumberNode, item.count.toString());
            }, this);
        },

        baseClass: "epi-facet-group",

        layout: function () {
            // summary:
            //      Resizes the facet group.
            // tags:
            //      public

            domGeometry.setMarginBox(this.containerNode, { l: 0, t: 0 });
            this._list.resize();
        },

        buildRendering: function () {
            // summary:
            //      Constructs the UI for this widget.
            // tags:
            //      protected

            this.inherited(arguments);

            this._setupItemList();
            this._setupClearButton();
        },

        _setupClearButton: function () {
            // summary:
            //      Creates clear button and then add it to the collapsible container.
            // tags:
            //      private

            var settings = {
                "class": "epi-chromelessButton",
                label: resources.clear,
                onClick: this._onClearButtonClicked.bind(this)
            };
            this.own(this._clearButton = new ToggleButton(settings));
            this.addButton(this._clearButton, { region: "header" });
            this._toggleClearButton();
        },

        _setupShowMoreButton: function () {
            // summary:
            //      Creates show more button and then add it to the collapsible container.
            // tags:
            //      private

            var settings = {
                "class": "epi-chromelessButton",
                iconClass: "epi-showMoreIcon",
                onClick: this._onShowMoreButtonClicked.bind(this)
            };
            this.own(this._showMoreButton = new ToggleButton(settings));
            this.addButton(this._showMoreButton, { region: "footer" });
        },

        _setupItemList: function () {
            // summary:
            //      Renderes facet item list inside the created collapsible container.
            // tags:
            //      private

            var listClass = declare([OnDemandList, Formatter, Selection, Keyboard, Focusable, Responsive]),
                settings = {
                    formatters: this._getFacetItemFormatters(),
                    cleanEmptyObservers: false,
                    commandCategory: "itemContext",
                    deselectOnRefresh: false,
                    farOffRemoval: Infinity,
                    refocusOnRefresh: true,
                    responsiveMap: { "epi-card-list--narrow": 570 }
                };

            this._list = new listClass(settings);
            this._list.maxEmptySpace = 0;
            domClass.add(this._list.domNode, "epi-grid-height--auto epi-card-list");
            this.addChild(this._list);

            this.own(
                this._list,
                aspect.before(this._list, "select", this._onBeforeItemClicked.bind(this), true),
                aspect.before(this._list, "renderArray", this._onBeforeRenderArray.bind(this)),
                aspect.around(this._list, "insertRow", this._aroundInsertRow.bind(this)),
                this._list.on("dgrid-cellfocusin", this._onItemClicked.bind(this))
            );
        },

        _aroundInsertRow: function (original) {
            // summary:
            //      Called 'around' the insertRow method to limit the number of rows rendered.
            // tags:
            //      private

            return function (object, parent, beforeNode, i, options) {
                if (this._showMoreButton && this._showMoreButton.get("checked")) {
                    return original.apply(this._list, arguments);
                }

                var itemsToShow = this.model.get("itemsToShow");
                if (itemsToShow > 0 && itemsToShow < i + 1) {
                    return {};
                }

                return original.apply(this._list, arguments);
            }.bind(this);
        },

        _onBeforeRenderArray: function (results, beforeNode, options) {
            // summary:
            //      Adds show more button when the total items are greater than limited number.
            // tags:
            //      private

            var itemsToShow = this.model.get("itemsToShow");
            if (!this._showMoreButton && itemsToShow > 0) {
                var checkResult = function (length) {
                    if (itemsToShow < length) {
                        this._setupShowMoreButton();
                    }
                }.bind(this);
                if (results.observe) {
                    results.then(function (results) {
                        checkResult(results.length);
                    }.bind(this));
                }
                else {
                    checkResult(results.length);
                }
            }
        },

        _onClearButtonClicked: function (evt) {
            // summary:
            //      Clears all selection.
            //      Fired when Clear button on this widget clicked.
            //      Emits selection changed event to its container.
            // evt: [Event]
            //      Click event.
            // tags:
            //      private

            this._list.clearSelection();
            this._toggleClearButton();

            this.emit("selection-changed", { "id": this.model.get("id"), items: [] });
        },

        _onShowMoreButtonClicked: function (evt) {
            // summary:
            //      Toggles showMore/showLess state and refresh the list.
            // evt: [Event]
            //      Click event.
            // tags:
            //      private

            this._showMoreButton.set("iconClass", this._showMoreButton.get("checked") ? "epi-showLessIcon" : "epi-showMoreIcon");
            this._list.refresh();
        },

        _onItemClicked: function (evt) {
            // summary:
            //      Fired when clicking on an item in the widget.
            //      Emits selection changed event to its container.
            // evt: [Event]
            //      dgrid-cellfocusin event.
            // tags:
            //      private

            this.defer(function () {
                if (this.get("selectionType") && this._currentItemSelected) {
                    this._list.deselect(evt.row, null);
                }

                this._toggleClearButton();
                this.emit("selection-changed", { "id": this.model.get("id"), items: this._getSelectedItems() });
            }.bind(this), 200);
        },

        _onBeforeItemClicked: function (row, toRow, value) {
            // summary:
            //      Stores state of the current row is selected or not.
            // tags:
            //      private

            if (typeof row !== "string") {
                this._currentItemSelected = domClass.contains(row, "dgrid-selected");
            }
        },

        _toggleClearButton: function () {
            // summary:
            //      Shows/hides the "Clear" button.
            // tags:
            //      private

            this._clearButton.set("showLabel", this.get("selectionType") && !epi.isEmpty(this._list.selection));
        },

        _getSelectedItems: function () {
            // summary:
            //      Gets all selected item data.
            // tags:
            //      private

            var items = [];
            Object.keys(this._list.selection).forEach(function (key) {
                if (this._list.selection[key]) {
                    items.push(key);
                }
            }, this);

            return items;
        },

        _getFacetItemFormatters: function () {
            // summary:
            //      Formatters for items in the facet group
            // tags:
            //      private

            var getIconClasses = this.model.getIconClasses.bind(this.model);
            return [
                function formatter(value, object, node, options) {
                    var map = {
                        iconClasses: getIconClasses(value),
                        name: entities.encode(value.name, entities.html),
                        count: value.count
                    };

                    return string.substitute(facetItemTemplate, map);
                }
            ];
        }

    });

});